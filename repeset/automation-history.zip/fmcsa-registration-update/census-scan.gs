﻿// Scan established carriers in bounded pages. Preview runs never advance this cursor.
function censusScanPage_() {
  const size = 250;
  const stored = Number(PropertiesService.getScriptProperties().getProperty('ah_census_scan_offset') || 0);
  const offset = Number.isSafeInteger(stored) && stored >= 0 ? stored : 0;
  const params = { '$select': censusColumns_(), '$where': censusFilter_(),
    '$order': 'dot_number DESC', '$limit': size, '$offset': offset };
  const query = Object.keys(params).map(k => encodeURIComponent(k) + '=' + encodeURIComponent(params[k])).join('&');
  const rows = publicJson_('https://data.transportation.gov/resource/' + AH.census + '.json?' + query);
  if (!Array.isArray(rows) || rows.length > size) throw new Error('Unexpected census scan response.');
  return { rows: rows, offset: offset, size: size };
}
function censusScanNext_(page, readyCount, checked, fresh) {
  if (!fresh || readyCount >= AH.mainLimit || checked >= AH.checkLimit) return page.offset;
  return page.rows.length < page.size ? 0 : page.offset + page.rows.length;
}
