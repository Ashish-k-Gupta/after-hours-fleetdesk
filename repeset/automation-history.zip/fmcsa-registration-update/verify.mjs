﻿import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';
const source = fs.readFileSync(new URL('./census-scan.gs', import.meta.url), 'utf8');
let stored = '500';
let requests = [];
let response = Array.from({ length: 250 }, (_, i) => ({ dot_number: String(i + 1) }));
const context = vm.createContext({
  AH: { census: 'az4n-8mr2', mainLimit: 99, checkLimit: 500 },
  PropertiesService: { getScriptProperties: () => ({ getProperty: () => stored }) },
  censusColumns_: () => 'dot_number,add_date',
  censusFilter_: () => "status_code='A'",
  publicJson_: url => { requests.push(url); return response; },
});
vm.runInContext(source, context);
const page = context.censusScanPage_();
const query = new URL(requests[0]).searchParams;
assert.equal(requests.length, 1, 'One bounded census request');
assert.equal(query.get('$limit'), '250');
assert.equal(query.get('$offset'), '500');
assert.equal(query.get('$where'), "status_code='A'", 'No registration-age predicate');
assert.equal(query.get('$order'), 'dot_number DESC');
assert.equal(context.censusScanNext_(page, 12, 20, true), 750);
assert.equal(context.censusScanNext_(page, 99, 105, true), 500, 'Retain page when daily ready limit reached');
assert.equal(context.censusScanNext_(page, 0, 20, false), 500, 'Retain page for stale sources');
assert.equal(context.censusScanNext_(page, 12, 500, true), 500, 'Retain page when check limit reached');
assert.equal(context.censusScanNext_({ rows: [], size: 250, offset: 500 }, 0, 0, true), 0);
assert.equal(context.censusScanNext_({ rows: Array(20), size: 250, offset: 500 }, 2, 10, true), 0);
for (const bad of ['-1', 'NaN', '1.5', 'Infinity']) {
  stored = bad;
  assert.equal(context.censusScanPage_().offset, 0);
}
stored = null;
assert.equal(context.censusScanPage_().offset, 0);
response = { error: 'upstream error' };
assert.throws(() => context.censusScanPage_(), /Unexpected census scan response/);
response = Array(251);
assert.throws(() => context.censusScanPage_(), /Unexpected census scan response/);
console.log('Passed: bounded fetch, unrestricted registration age, cursor retention, wraparound, and invalid state/response handling.');
