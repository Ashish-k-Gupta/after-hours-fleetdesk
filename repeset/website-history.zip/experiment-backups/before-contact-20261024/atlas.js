import {journeyAt, clamp} from './journey.js';
import {stageFor, calloutFor, telemetryFor} from './stage-copy.js';
const $ = s => document.querySelector(s), chapters = [...document.querySelectorAll('.chapter')];
const reduced = matchMedia('(prefers-reduced-motion: reduce)');
let scene = null, raf = 0, anchors = [], measurePending = true, overview = false;
let lastStage = -1, failed = false, paused = false, nextRenderAt = 0, lastRender = 0, initializing = false;
const frameBudget = 1000 / 60;
const setText = (element, text) => {if (element.textContent !== text) element.textContent = text;};

function measure() {
  const header = $('.route-header').getBoundingClientRect().height;
  const mobile = matchMedia('(max-width:620px)').matches;
  const offset = header + (mobile ? $('.world-stage').getBoundingClientRect().height : 0);
  anchors = chapters.map(e => ({id: e.id, y: e.getBoundingClientRect().top + scrollY - offset, p: Number(e.dataset.point)}));
  const last = chapters.at(-1);
  anchors.push({id: 'end', y: Math.max(anchors.at(-1).y + 200, last.getBoundingClientRect().bottom + scrollY - innerHeight + 30), p: 1});
  measurePending = false;
}
function progress() {
  const y = scrollY;
  if (y <= anchors[0].y) return 0;
  for (let i = 0; i < anchors.length - 1; i++) {
    const a = anchors[i], b = anchors[i + 1];
    if (y <= b.y) return a.p + (b.p - a.p) * clamp((y - a.y) / (b.y - a.y));
  }
  return 1;
}
function invalidate() {if (!raf && !document.hidden) raf = requestAnimationFrame(draw);}
function draw(timestamp) {
  raf = 0;
  if (document.hidden) return;
  if (nextRenderAt && timestamp < nextRenderAt - .4) {invalidate(); return;}
  nextRenderAt = nextRenderAt && timestamp - nextRenderAt < frameBudget ? nextRenderAt + frameBudget : timestamp + frameBudget;
  const dt = lastRender ? Math.min(.05, (timestamp - lastRender) / 1000) : 1 / 60;
  lastRender = timestamp;
  if (measurePending || !anchors.length) measure();
  const p = progress(), raw = journeyAt(p);
  const state = reduced.matches ? journeyAt([0, .42, .61, 1, 1][raw.phase]) : raw;
  const stage = stageFor(state), callout = calloutFor(state), telemetry = telemetryFor(state);
  if (document.body.dataset.stage !== String(stage)) document.body.dataset.stage = String(stage);
  for (let i = 0; i < chapters.length; i++) chapters[i].classList.toggle('is-active', i === stage);
  setText($('[data-percent]'), String(Math.round(p * 100)).padStart(2, '0') + '%');
  setText($('[data-header-status]'), state.pod ? 'DELIVERY COMPLETE' : 'FOLLOW THE LOAD');
  setText($('[data-note-kicker]'), callout.title); setText($('[data-scene-status]'), callout.message);
  setText($('[data-pallet-count]'), telemetry.pallets); setText($('[data-document-state]'), telemetry.document);
  const loadPercent = $('[data-load-percent]'); setText(loadPercent, telemetry.percent); loadPercent.hidden = !telemetry.percent;
  $('[data-motion-toggle]').hidden = (stage !== 1 && stage !== 2) || reduced.matches || failed;
  if (stage !== lastStage) {setText($('[data-announcement]'), callout.title + '. ' + callout.message); lastStage = stage;}
  if (scene && !failed) {
    try {
      const point = scene.applyState(state, {overview, dt, reducedMotion: reduced.matches, paused});
      const note = $('[data-map-note]'), r = $('.world-stage').getBoundingClientRect();
      const lower = stage === 0 && point.y > r.height * .65;
      const left = point.mobile ? Math.max(14, Math.min(r.width - note.offsetWidth - 14, point.x + 12)) : Math.max(lower ? 20 : r.width * .52, Math.min(r.width - note.offsetWidth - 35, point.x + 18));
      const top = point.mobile ? Math.max(64, Math.min(r.height - note.offsetHeight - 68, point.y - note.offsetHeight - 24)) : Math.max(74, Math.min(r.height - note.offsetHeight - 65, point.y - (lower ? 20 : 55)));
      const noteLeft = Math.round(left) + 'px', noteTop = Math.round(top) + 'px';
      if (note.style.left !== noteLeft) note.style.left = noteLeft;
      if (note.style.top !== noteTop) note.style.top = noteTop;
      if (point.needsFrame) invalidate();
    } catch (error) {console.error(error); showError();}
  }
}
function showError() {
  failed = true; $('[data-scene-error]').hidden = false; $('[data-motion-toggle]').hidden = true;
  if (raf) cancelAnimationFrame(raf); raf = 0;
  scene?.dispose(); scene = null;
}
function navigate(id, behavior = reduced.matches ? 'instant' : 'smooth') {
  if (measurePending || !anchors.length) measure();
  // Preserve incoming links to the earlier fourth chapter.
  const point = anchors.find(a => a.id === (id === 'delivered' ? 'end' : id));
  if (point) scrollTo({top: Math.max(0, point.y + (point.p ? 1 : 0)), behavior});
}
document.addEventListener('scroll', invalidate, {passive: true});
addEventListener('resize', () => {measurePending = true; invalidate();}, {passive: true});
document.addEventListener('visibilitychange', () => {
  if (raf) cancelAnimationFrame(raf); raf = 0; nextRenderAt = 0; lastRender = 0;
  if (!document.hidden) invalidate();
});
for (const link of document.querySelectorAll('a[href^="#"]')) link.addEventListener('click', e => {
  const id = link.getAttribute('href').slice(1);
  if (!document.getElementById(id) && id !== 'delivered') return;
  e.preventDefault(); history.replaceState(null, '', '#' + id); navigate(id);
});
for (const button of document.querySelectorAll('[data-camera]')) button.addEventListener('click', () => {
  overview = button.dataset.camera === 'atlas';
  for (const e of document.querySelectorAll('[data-camera]')) e.setAttribute('aria-pressed', String(e === button));
  invalidate();
});
$('[data-motion-toggle]').addEventListener('click', () => {
  paused = !paused; $('[data-motion-toggle]').setAttribute('aria-pressed', String(paused));
  setText($('[data-motion-toggle]'), paused ? 'RESUME MOTION' : 'PAUSE MOTION'); invalidate();
});
reduced.addEventListener('change', () => {$('[data-motion-note]').hidden = !reduced.matches; invalidate();});
$('#scene-host').addEventListener('journey-error', showError);
addEventListener('pagehide', () => {
  if (raf) cancelAnimationFrame(raf); raf = 0;
  scene?.dispose(); scene = null; nextRenderAt = 0; lastRender = 0;
});
addEventListener('pageshow', () => {measurePending = true; if (!scene && !failed) void init(); invalidate();});
async function init() {
  if (initializing) return; initializing = true;
  invalidate(); $('[data-motion-note]').hidden = !reduced.matches;
  try {
    // No intro wall or font-loading gate: start the local geometry immediately.
    const {createJourneyScene} = await import('./scene.js');
    scene = createJourneyScene($('#scene-host'), invalidate);
    measurePending = true; invalidate();
  } catch (error) {console.error('Atlas initialization failed:', error); showError();}
  finally {initializing = false;}
}
document.fonts.ready.then(() => {
  measurePending = true;
  if (location.hash) navigate(location.hash.slice(1), 'instant');
  invalidate();
});
void init();
