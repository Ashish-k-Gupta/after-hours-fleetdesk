# Route Atlas design QA — 2026-10-24

final result: passed

Passed for the authorized **interactive 3D adaptation** of the selected atlas direction. This is not a pixel-for-pixel reproduction of the generated illustration. The user specifically requested retaining the existing live 3D truck, pickup and delivery behavior. The source image is reference only and is not used as hero artwork.

## Evidence and normalization

- Visual target: `references/selected-atlas.png`, 1415 × 916 pixels. Removed the 31-pixel left and 14-pixel right outer dark margins for `references/selected-atlas-normalized.png`, 1370 × 916.
- Implementation: http://localhost:4185.
- Reference-size capture: `preview-reference-size.png`, browser CSS viewport 1370 × 916; captured image 1355 × 906. Normalized proportionally to 1370 × 916 in the comparison to account for the browser capture scale. No design elements were stretched separately.
- Full-view evidence: `comparison.png`, source left, implementation right, 2740 × 916.
- Focused typography evidence: `comparison-typography.png`, source left, implementation right. Compared title weight, wrapping, margins, body size, and scroll cue.
- Additional browser evidence: `preview-mobile.png` at CSS 390 × 844, captured 375 × 811; `preview-delivered.png` at CSS 1370 × 916, captured 1355 × 906; `preview-desktop.png` at the final normal browser size, CSS 1536 × 674. A 1536 × 730 desktop view was also tested.
- Both source and rendered images were opened together as composite comparisons before the final review. The final shorter-screen framing fix was checked in the browser and saved in `preview-desktop.png`.

## State and intentional differences

The selected image shows a pickup moment under the entry headline. The implemented page begins at the yard because the requested journey starts with a coupled truck and trailer. Native scrolling then reaches the pickup, transit, receiver and delivery states. The entry layout, brand, headline, cream background, green typography, orange accents, road, landmarks and callout treatment were compared. Loading and delivery were separately checked in their actual live states.

The warehouses, tree models, terrain and road use original procedural Three.js geometry. Their silhouettes and materials are simpler than the generated illustration. The moving camera and route geometry are adapted to accommodate the existing tractor/reefer and dock animation. These are intentional consequences of the user's live-3D requirement; the implementation does not claim illustration-level visual identity.

## Findings and fixes

No remaining actionable P0/P1/P2 findings for this adaptation.

Comparison history:

1. Initial browser pass found missing road surfaces, rounded hills, and geometry behind copy. Corrected road triangle winding, replaced the hills with triangulated terrain, and added screen-space compositing to preserve the reading area. The road and terrain are visible in the saved comparison; chapter text remains clear beside the dock scene.
2. Story copy could advance to the next chapter while the current load was still loading. Desktop copy now stays pinned to the active operational stage. Mobile retains natural chapter scrolling beneath the pinned scene. Checked loading at 38% with three pallets and the pickup chapter visible.
3. The first river placement crossed the receiver footprint. Moved the river/bridge and arranged the receiver farther along the route. Final delivery evidence shows the reefer at the receiving dock, clear of the river.
4. The first reference comparison showed lighter title weight, smaller type, and excess left inset. Added the matching locally available 700 font weight, adjusted the display size and left inset, and re-captured both full and focused comparisons.
5. Small secondary copy had insufficient contrast. Changed text to `#63735d` on `#f5f2e7` (4.52:1), darkened small orange labels, and used `#c06e40` for large emphasized words (3.38:1). Re-captured and compared.
6. A shorter desktop window clipped the starting truck. Added an aspect-dependent camera offset and adjusted the entry compositing fade so the complete coupled rig stays visible. Verified the resulting view at CSS 1536 × 674; saved as `preview-desktop.png`.

## Required fidelity surfaces

- **Typography:** local IBM Plex Sans 400/600/700, matching the selected design's broad sans serif direction and two-line headline. Comfortable body measures. Headline wrapping, type weight and supporting copy checked in the focused comparison. The generated image does not identify a specific font family; Plex is the project's existing family.
- **Spacing/layout:** open page-wide landscape, left reading area, slim route navigation, contextual notes, no containing scene card. Landscape remains pinned. Header, story and controls fit the desktop and mobile views without horizontal overflow. The complete route is available through the camera control.
- **Color/tokens:** warm cream, forest green, muted landscape, and copper accents retained. Secondary text contrast improved as noted above. This was a scoped readability check, not a complete WCAG audit.
- **Artwork:** actual WebGL truck, reefer, road, bridge, trees, terrain, warehouse docks, pallets and forklift. No rasterized hero substitute. The retained original model is used for both the scene and the small top-route truck render.
- **Copy:** selected entry headline and supporting message retained. Operational chapters explain tracking, communication and follow-through. Four years of experience comes from the supplied background. The illustrative load is clearly labeled; no customer results, contact details or employer ownership claims are invented.

## Interaction verification

- Stage links move through the native scroll timeline; no wheel/touch interception.
- Coupled rig at the yard; pickup approach, backing and loading.
- Partial cargo while loading; six pallets and BOL confirmed at departure.
- Curved-road travel; truck and reefer remain coupled.
- Receiver approach, backing and unloading; final state 100%, zero pallets, POD received.
- Reverse navigation restores the empty starting state.
- Both Whole Route and Follow Load controls change the view and preserve progress.
- Mobile navigation aligns the chapter beneath the pinned scene; scene top remains at 110 pixels while scrolling; no horizontal overflow.
- Browser console warnings/errors: none in the final captured session.
- `npm.cmd run check` and the 2,001-sample journey verifier passed. The verifier covers continuous poses, route progress, cargo/document states, exact hitch positions, door bounds and cab/trailer clearance.

## Follow-up polish and limits

P3: the generated illustration has more detailed vegetation, warehouse facades and terrain materials. The original procedural models are deliberately retained and can be detailed further in a later iteration. The top route labels are compact, especially on mobile. Reduced-motion and WebGL-failure branches are implemented but were not exercised by changing operating-system/browser preferences in this session. Browser coverage is Chrome desktop with responsive viewport testing, not physical-device testing.

Implementation checklist: complete for this local prototype. Earlier versions remain available; no deployment or communications were performed.

## Approved header removal

The user subsequently requested removing the miniature top truck, route line, and Yard / Pickup / In Transit / Delivery labels. Removed that entire route navigation component, its scroll-update bindings, and the unused miniature renderer. Kept the main 3D journey and shortened the header to 80px desktop / 72px mobile. The original reference comparison above documents the earlier version and is superseded for this header area by the user's removal request.

Scoped verification passed: syntax check; browser confirmation that the route component is absent; main scene renders; scroll cue reaches pickup at 16% with the appropriate status; no browser warnings/errors; mobile header is 72px with no horizontal overflow. New desktop evidence: `preview-header-updated.png`. Temporary mobile viewport override was reset. No changes were made to the earlier sites.

## Approved readability revision

The user found the supporting type too small. Increased body copy to 16–17px, work notes to 15–16px, scene notes to 15–17px, and most labels/captions to 11–13px. Increased camera button hit areas to 44px. Added space around the text, allowed two chapter headings to wrap into fewer lines on wide screens, and moved mobile notes above the vehicle so the enlarged text does not cover it. Camera controls have a light backing for contrast over scenery. Notes have a stable width to prevent size changes as they reposition.

Scoped verification passed: the longest desktop chapter fits at 1536 × 674 (active copy bottom 517px); the normal 1920 × 889 view was inspected; 390 × 844 mobile text and notes were visually checked; 320px and 800px layouts report no horizontal overflow. The 800px layout uses normal chapter flow rather than clipped fixed text. JavaScript syntax check passed. The 3D scroll states remain active. Evidence: `preview-readable-desktop.png`, `preview-readable-mobile.png`. Mobile evidence uses a page-coordinate clip of the visible viewport because the browser's ordinary emulated capture was scaled into a thumbnail. The viewport override was reset before handoff.

The original image comparisons above are historical art-direction evidence; the user's newer readability request supersedes the original small typography.

## Separate load lifecycle study — 24 October 2026

User requested showing the operational work and customer communication throughout a load, on a different page. Added `/load-lifecycle/` with seven stages: booked, dispatched, shipper check-in, pickup/BOL review, in transit, receiver check-in, and delivered/POD follow-up. The original homepage, atlas controller, atlas CSS, scene renderer, and journey timeline have identical SHA-256 hashes before and after this addition.

The new page reuses the existing 3D assets with a separate controller and stylesheet. Its native-scroll anchors map pickup to a fully loaded/BOL-ready state, transit to the road, receiver check-in to the receiver, and delivery to the unloaded/POD state. It includes stage links, camera buttons, expandable illustrative update wording, discrete reduced-motion poses, WebGL error feedback, and scene reinitialization after browser back/forward cache restoration. Customer update examples are text only. No form, sending mechanism, outreach, or deployment was added.

Verification completed: `npm.cmd run check`; the existing 2,001-sample motion verifier; HTTP 200 for the new page and 14 linked/shared resources including local fonts and module dependencies; unique IDs and valid fragment links; seven ordered stage anchors and six expandable update examples; and scene milestone checks for pickup, transit, receiver arrival and delivery.

Visual verification is pending. The browser tool reported Chrome unavailable and an empty browser/app inventory. No desktop/mobile screenshots or browser interaction tests were possible in this session. Responsive CSS, camera framing, expanded examples, scrolling, keyboard navigation, reduced motion, WebGL fallback and back/forward restoration need a browser review. The earlier screenshots in this folder show the original atlas and are not evidence for this new page.

## Lifecycle route integration — 24 October 2026

User clarified that the lifecycle should be a discoverable route within this same website. Added a **Load lifecycle** link in the atlas header. The lifecycle page uses the same portfolio branding and a header navigation with **Atlas** and **Load lifecycle**, with `aria-current="page"` on the active route. The header link has a 44px minimum target; compact screen rules retain the home percentage readout and use a shorter link without its decorative arrow. No removed miniature route bar was restored.

The same server now redirects directory requests without a trailing slash to the slash form, preserving query parameters. This makes both `/load-lifecycle` and `/load-lifecycle/` resolve with working relative CSS/JavaScript. The homepage markup and header CSS were intentionally changed for navigation; the earlier unchanged-file comparison documents the first addition only. The 3D scene, motion timeline and original atlas controller remain unchanged. Syntax and same-origin route/link checks passed. Browser visual review remains pending as documented above.

## Plain lifecycle page — 24 October 2026

User requested removing the entire truck/trailer 3D experience from the second page and making it plain. Removed the scene markup, camera controls, live scene captions, motion attributes, loading/error feedback, JavaScript dependency and lifecycle controller file. Replaced the split-screen and viewport-height layout with a centered reading column and natural section spacing. The seven stages, operations checks, six native expandable customer-update examples and same-site navigation remain. Stage links and disclosures use native HTML; the page needs no JavaScript. The homepage and shared 3D files were not edited in this revision.

Verification: project syntax check passed; `/load-lifecycle/`, its stylesheet and local fonts return HTTP 200; all fragment links reference unique existing IDs; all seven stages and six disclosures remain; the lifecycle HTML has zero script tags and no scene/camera markup; CSS contains no scene selectors, map spacing or viewport-sized chapter gaps; the deleted lifecycle controller returns 404; the homepage still serves its scene host, atlas script and lifecycle navigation. Visual browser review remains pending. Earlier 3D-page notes above are historical and superseded for this route.

## Seven-stage progress with a small miniature — 24 October 2026

User requested a seven-stage load progression and clarified that 3D is acceptable if small. Replaced the plain stage index with a connected, numbered strip: Load booked; Truck dispatched; Checked-in shipper; Pickup & BOL reviewed; In transit; At receiver; Delivered. Selecting a stage shows its short operational summary, updates the current/completed appearance and detail anchor, and offers Previous/Next controls. The strip has native horizontal scrolling on narrow screens and retains ordinary task-section anchors without JavaScript.

The 3D element is confined to a 240 × 176px desktop / 220 × 160px mobile thumbnail inside the progress panel. It reuses only the original tractor/reefer model plus simple dock, road and cargo geometry. Stage changes update these objects; there is no animation loop, full-page landscape, scroll mapping or camera UI. If WebGL or its module is unavailable, the thumbnail hides and the text interaction remains usable. The separate long-form task sections and six native customer-update disclosures remain below. This latest instruction supersedes the earlier blanket removal of 3D from the second page; keep the miniature small.

Checks passed: project syntax; HTTP 200 for the page and eight stylesheet/module/font dependencies; exact seven labels and valid task-section targets; controller simulation of all seven transitions, previous/next limits, direct selection, completed/current states, detail-link updates and missing-miniature fallback; and camera projection of all seven model poses at three small viewport sizes (21 combinations). These are code, HTTP and geometry checks, not browser evidence. The browser inventory was still empty, so desktop/mobile appearance, horizontal scrolling, keyboard behavior and actual WebGL output remain visually unverified. Original homepage/controller/scene/model files were not edited.

## Vertical sidebar and scroll completion — 24 October 2026

User approved the previous visual in their screenshot and requested a vertical progression on the side, automatic completion while scrolling, and checkbox-style completion animation. Reworked the page into a sticky left sidebar and a reading column. The seven stage links remain native anchors. Scroll position determines the active section; earlier stages become completed. The final stage completes after its section has been read or the document end is reached. Scrolling backward rewinds both stage and task completion. The old manual Previous/Next preview controls were removed; native Next links in the task sections remain.

All 24 operational task rows now contain decorative checkboxes. A task checks when its text passes the viewport reading line, and the stage checkbox checks after the section is passed. The checkmark draws over 260ms with a 300ms checkbox pop. Reduced-motion preferences remove animation/transitions and smooth scrolling. Initial/deep-link restoration suppresses completion animations. Accessible current/completed states, section status text, a completion count and stage-change announcements accompany the visual feedback. The checkboxes illustrate the fictional walkthrough and do not alter real shipment records.

Desktop keeps a 220 × 110px (200 × 110px on narrower desktop) miniature below the stage list. The sidebar has a viewport-height limit and its own overflow for short windows. At widths of 760px or less it becomes a narrow vertical numbered rail; stage names remain accessible, and the miniature is not mounted. The task column continues to scroll normally. Fonts, disclosure toggles, viewport changes and back/forward restoration recalculate progress from current geometry. The shared 3D model files, homepage and original atlas were not changed.

Checks passed: project syntax; HTTP 200 for the page and its four lifecycle code/style resources; seven stage checkboxes, 24 task checkboxes, seven sections, six disclosures, unique IDs and valid fragment links; scroll-state checks for all stages, 280 forward samples, reverse reset, individual task thresholds, short viewports and final/document-end completion; actual-controller DOM simulation for current/completed states, counts, all task checks, disclosure recalculation and back/forward restore; and all seven model poses fitting two small camera sizes (14 combinations).

Visual verification remains pending. The browser inventory is still empty. The user's screenshot verifies the previously approved horizontal version only; it is not browser evidence for this sidebar revision. Review sticky behavior, small-screen rail spacing, actual checkmark motion, reduced motion, keyboard navigation and miniature rendering in a browser when available.

## Content reduction — 24 October 2026

User found the page too dense and requested a clean, simple version. Replaced the marketing introduction, 24 checklist rows, confirmation notes, six sample messages and closing section with a small heading and seven stage titles, each followed by one short action sentence. The seven action sentences total 57 words. Simplified the sidebar heading and footer and removed the unused task/disclosure styles and controller code. Vertical sidebar progress, stage checkbox animations, native stage links, reduced-motion support and the existing small desktop 3D preview remain. The homepage and shared 3D files were not changed.

Adjusted the activation line to move lower as the shorter page approaches its end, preserving all seven active stages without adding large blank sections. Project syntax passed; page and four lifecycle code/style resources return HTTP 200; seven titles, seven actions, unique IDs and valid anchors were checked; old checklist/notes/message markup is absent. Four simulated viewport layouts each traverse every stage, complete all seven and reset on reverse scrolling. The simplified layout has not been visually reviewed in a browser.

## Enlarged 3D stage view — 24 October 2026

User requested enlarging the scene now that the page has less copy and considering a better placement. Moved the scene out of the progress sidebar into its own grid column. Above 1100px the layout has progress on the left, short stage actions in the middle, and an enlarged sticky 3D view on the right. The view uses its available column width and a 320–460px canvas height, capped for short windows. The active stage name appears beneath the scene. The page heading spans the text and scene columns.

At 1100px and below the scene is inline beneath the heading and above the stage actions (340px high on tablets, 210–300px on phones). It is now enabled on phones too. The compact vertical progress rail remains. WebGL/module failure hides the scene and returns the layout to its text columns. Scene availability and grid reflow schedule progress recalculation; the story and content are both observed for size changes. The seven short actions, checkbox animation, scroll progression and original homepage remain.

Checks passed: project syntax; page and four lifecycle code/style resources HTTP 200; balanced HTML tags, unique IDs and valid anchors; scene and heading confirmed as direct story-grid children outside the progress sidebar; seven short actions retained; all seven model stages fit seven enlarged desktop, tablet, phone and short-window camera sizes (49 combinations). These are structural and geometry checks. The browser inventory was empty again, so rendered layout, sticky behavior, phone placement and actual WebGL appearance remain visually unverified.

## Distinct stage animations — 24 October 2026

User requested substantially more animation, specifically different actions for load booked, BOL review and delivery. Added deterministic short sequences for all seven stages: dispatch sheet checks/envelope/driver acknowledgement; departing truck, rolling wheels and customer update; shipper backing/arrival pin/check-in; forklift loading plus a scanned BOL with sequential checks and stamp; transit lane movement/checkpoints/update; receiver backing/check-in/doors; and forklift unloading with a signed POD and confirmation stamp. Documents are procedural 3D clipboards with local canvas-texture headings, drawn geometric checkmarks and a drawn signature. All paperwork/messages remain illustrative; there is no outgoing integration.

Each stage plays once for 6–8.6 seconds, then stops at its outcome. Play/Pause and Replay controls are beneath the scene. Playback suspends outside the viewport or in a hidden tab. Reduced-motion preferences show the final pose; deliberate play/replay is still available. A fixed camera envelope prevents zoom changes while objects move. Frames are painted at approximately 30fps while playing, and listeners, observers, pending frames and GPU resources are released on disposal. Existing enlarged desktop/inline responsive placement and seven short stage actions remain.

Fixed an interaction mismatch on the concise page: the dynamically lowered reading line meant ordinary anchor placement could select a later stage. Enhanced the same anchor links with a matching inverse scroll target. All seven requested targets select the corresponding stage across four viewport layouts (28 cases), and selecting the already-current stage replays it. No-JavaScript anchor fallback remains.

Verification passed: project syntax and served resources/controls; `npm.cmd run verify:stages` checks all seven distinct outcomes, 567 animation poses, 1,029 camera-frame combinations, exact hitch attachment, loading-door constraints, BOL checks, signed POD, replay determinism and the 28 navigation targets. A separate simulation of the actual playback module with a renderer stub passed autoplay, pause, replay, natural stop, offscreen/tab suspension, reduced-motion final pose, explicit reduced-motion replay and disposal. The stub verifies scheduling and lifecycle behavior, not graphics.

The browser inventory remains empty. Actual WebGL appearance, document-label readability, visible animation timing, forklift motion, control layout and responsive visual QA are still pending. Original homepage, main atlas controller/scene and original truck/trailer assets were not edited.
