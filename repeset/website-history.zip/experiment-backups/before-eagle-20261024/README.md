# After Hours — The Route Atlas

## Load lifecycle route - 24 October 2026

Open http://localhost:4185 and choose **Load lifecycle** to visit `/load-lifecycle/` in the same portfolio. Latest direction: keep this page clean and simple. It contains a small heading and seven stage titles, with one short action sentence each (57 action words in total). The long introduction, 24-item checklist, confirmation notes, sample messages and closing essay have been removed.

Keep the sticky vertical seven-stage sidebar, scroll-driven completion checkmarks and reduced-motion behavior. The Three.js/WebGL view has been enlarged and moved out of the sidebar: desktop widths above 1100px use progress, task text and a separate sticky scene column. At 1100px and below the scene sits inline below the heading, including on phones. The mobile progress list remains a numbered rail. Scrolling back resets completion. The concise layout uses a reading position that gradually moves lower while approaching the page end, so all seven stages can become active even on the shorter page. The stage links retain ordinary anchor targets, with enhanced scroll positioning so selecting a stage reliably starts its matching animation; selecting the current stage replays it. There are no forms, messages sent or shipment records updated; the footer identifies the workflow as illustrative.

Files: `dist/load-lifecycle/index.html`, `lifecycle.css`, `progress.js`, `progress-state.js`, `stage-motion.js` and `progress-scene.js`. Local fonts and the original Three.js truck models are reused. The homepage and original truck/trailer model files are unchanged. The enlarged stage view now plays a distinct finite 6-8.6 second sequence for each stage, with Play/Pause and Replay controls. It stops after the sequence, suspends when offscreen or the tab is hidden, and defaults to a final static pose for reduced motion. Explicit playback remains available.

Verification: project syntax and HTTP/fragment checks passed; seven titles and seven short actions remain; no checklist/notes/example-message markup remains; all seven stages activate and complete in four simulated viewport layouts, with reverse reset. The enlarged scene passes all-stage camera-fit checks at seven desktop, tablet, phone and short-window sizes (49 combinations). HTML structure, anchors and served resources also pass. Browser visual review is pending. See `design-qa.md` for prior revisions.

### Stage animations

- Load booked: dispatch sheet checks, envelope sent to the driver, acknowledgement.
- Truck dispatched: truck departure, rolling wheels/road and customer update.
- Checked-in shipper: backing into the pickup dock, arrival marker and check-in confirmation.
- Pickup & BOL reviewed: forklift/pallet loading, scanning the BOL, three review checks and a stamp.
- In transit: moving road/wheels, route checkpoints and customer update.
- At receiver: backing into the receiver, arrival marker and opening trailer doors.
- Delivered: forklift unloading, POD signature and delivery-confirmation stamp.

The paperwork, messages and freight remain illustrative geometry, with no sending or record changes. The visible page keeps its seven short actions. Document headings use local canvas textures; all models and runtime modules are local.

Run `npm.cmd run verify:stages` for seven distinct outcomes, 567 sampled animation poses, 1,029 camera projections, hitch/cargo/door checks, replay determinism and 28 stage-navigation targets. Actual playback code also passed a renderer-stub simulation for autoplay, pause, replay, finite stop, offscreen/tab suspension, reduced motion and disposal. These checks do not replace visual WebGL review; the browser inventory remains empty.

Progress saved for the next session on 2026-10-24. Start with [CHECKPOINT.json](CHECKPOINT.json) for the latest decisions, file map, constraints, verification results, and restart instructions. A timestamped project backup is stored in `D:/Ashish/output/logistics-checkpoints`.

A separate, local version based on the user's selected Route Atlas visual. The earlier portfolios and 3D experiments remain unchanged at ports 4182, 4183, and 4184.

Run `npm.cmd run dev` and open http://localhost:4185. No install or build is needed. Keep the preview running for the user's review.

The landscape is live Three.js geometry, not a hero image. Native page scrolling moves the original orange tractor and white reefer along a shared curved road, into pickup and delivery docks, and through loading and unloading. An orange road trace follows progress. The camera starts with an atlas overview and moves closer to the load. The Whole Route / Follow Load controls change the camera without resetting the load. The top route progress bar was removed at the user's request; the brand and compact progress readout remain in a shorter header.

Desktop text stays with its operational stage. Mobile uses a pinned 3D scene above naturally scrolling chapters. Scrolling backward rewinds the entire deterministic sequence. Reduced-motion preferences use discrete stage poses and instant navigation. Rendering is event-driven; there is no continuous animation loop.

The selected image is composition and art-direction reference only, saved under `references/selected-atlas.png`. It is not shipped as website artwork. Existing original procedural 3D truck and reefer assets are reused from our earlier experiment; the road, river, bridge, landscape and camera behavior are new. All JavaScript, Three.js, and IBM Plex fonts are local with their included MIT/OFL licenses.

This is an illustrative fictional load with six sample pallets. Status notes and paperwork labels demonstrate the workflow; they do not send messages, generate documents, or claim a real customer's activity. Personal claims use the supplied four years of US logistics experience and tracking/communication duties. No email sending, contact integrations, ownership disclosures, or deployment is included.

Files:

- `dist/index.html`, `atlas.css`, `atlas.js`: responsive page, chapters, native-scroll mapping and view controls.
- `dist/journey.js`, `route.js`: deterministic load timeline and shared road curve.
- `dist/landscape.js`, `world.js`: road, river, bridge, forest, yard, warehouses, cargo and forklift.
- `dist/scene.js`, `rig-models.js`: WebGL renderer, two camera modes and model assembly.
- `scripts/verify-journey.mjs`: 2,001 sampled positions, cargo/document states, continuity, exact hitch positions and cab/trailer clearance.

Use `npm.cmd run check` and `npm.cmd run verify`. Browser evidence and remaining visual differences are recorded in `design-qa.md`.

Readability revision: body copy is 16–17px, operational notes are 15–17px, and most supporting labels are 11–13px. Camera buttons have 44px hit areas. Larger notes sit above the truck on mobile. Narrow tablet chapters use natural scrolling to keep the larger copy accessible. Updated previews: `preview-readable-desktop.png` and `preview-readable-mobile.png`.
