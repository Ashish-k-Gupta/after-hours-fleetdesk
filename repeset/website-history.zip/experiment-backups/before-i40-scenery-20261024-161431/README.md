# After Hours — The Route Atlas

## Experience section - 24 October 2026

The full employment history from the earlier After Hours portfolio (port 4182) is now part of the Route Atlas homepage, after the delivery chapter and before the footer. Direct link: http://localhost:4185/#experience. It contains the current full-time Laut tracking/customer-communication role supporting Laut, FBT and Harrison; Quality Enterprise (November 2022-August 2023); and full-time Sigea Solutions (February-November 2022), primarily supporting Freon Logistics with additional LDH Xpress and Quad work. Responsibilities, Patiala/Bakersfield context and the six-week main-shift / after-hours rotation follow the user-confirmed earlier website. No new current-role start date, after-hours rotation length or freelance coverage hours are inferred.

The section uses the existing cream/forest/terracotta palette, a two-column editorial history on desktop and a single column at 800px and below. It is ordinary scrolling content, outside the four load-story chapters. Its employment-context note distinguishes these roles from the separate part-time/weekend service. The user's visible personal name stays removed, fleet size remains 5-15 trucks, and the supplied business email is preserved. No employer logos, new testimonials, carrier records or resume download were added.

Experience links are available in desktop navigation, the introductory four-year note and delivery closeout. A third Discuss your coverage button appears at the end of the history and opens the same email dialog. When the history reaches the header, the fixed scene and fixed story text become hidden; scene controls become inert and WebGL frames stop. Returning to the journey restores them. The header status/link follows the reading mode. The original journey progress ends at delivery and stays at 100% throughout the history, rather than stretching the route across the added text.

Verification: npm run check and verify:atlas pass. The production-controller harness additionally verifies desktop/mobile experience anchor positions, scene hiding/inert state, idle rendering, returning to the yard, legacy delivered links and reduced-motion navigation. Served HTML checks confirm three roles, eight named businesses, expected dates/rotation, unique IDs and valid local anchors, three contact triggers, preserved fleet size/email and no visible personal name or previously excluded role/relationship details. The homepage and runtime/lifecycle resources return HTTP 200. These checks do not replace a real browser visual review, which remains pending. The preceding HTML, CSS, controller and project notes are copied in experiment-backups/before-experience-20261024-160445/.

## Service summary and contact action - 24 October 2026

The homepage now states the service and audience near the hero: tracking, driver follow-ups, broker updates and after-hours support for US fleets with 5-15 trucks. A forest-green Discuss your coverage button appears beside the journey link and again at delivery closeout. Both open one native, keyboard-accessible dialog with the user-provided business email afterhours.fleetdesk@gmail.com. The email link opens a mail draft addressed to that account with the subject Fleet coverage. The coming-soon placeholder has been removed. There is no lead form or outgoing communication integration. Ambient animation pauses while the dialog is open and resumes on close, respecting the existing manual pause setting.

The visible personal name remains removed from the intro and footer. The earlier SEO description is unchanged. Local preview: http://localhost:4185. The preview server was restarted for this revision. Syntax checks, the existing atlas scene/controller verification, and HTTP/markup checks pass. Browser inventory is still empty, so actual visual layout and native-dialog keyboard behavior have not been checked in a live browser. A copy of the preceding index.html, atlas.css, atlas.js and checkpoint is in experiment-backups/before-contact-20261024/.

## Small dock flag - 24 October 2026

Added one muted American flag on a short pole at the pickup dock's outer apron corner. Its thirteen stripes and fifty stars are drawn locally; a small procedural cloth mesh gives it a gentle flutter during Stage 01. Existing Pause/Resume Motion controls now appear at the dock too. Reduced motion keeps the flag static, hidden tabs suspend rendering, and the eagle remains unchanged. The optional flag module is `dist/dock-flag.js`; the pre-flag snapshot is `experiment-backups/before-dock-flag-20261024/`.

Syntax, existing atlas scene/controller checks and HTTP module checks pass. No browser surface is available, so appearance still needs visual review.

## Brand and eagle experiment - 24 October 2026

Review at http://localhost:4185. The homepage keeps the existing live miniature and scrolling journey, with the opening yard and exactly three operational chapters: At the dock, In transit and At the receiver. The supplied headlines, operational copy and help text are installed. The old separate fourth delivery chapter is merged into the receiver chapter; incoming `#delivered` links still reach closeout. The removed top route progress bar has not been restored.

The Atlas now uses a dry van with six actual sample pallet models and a subtle loading/unloading cutaway. A shared, light-reactive AFTER HOURS / dual-slash decal is on both trailer sides and the pickup dock header. The separate seven-stage Load lifecycle page still uses its original reefer and animations.

Stage 02 activates a 144-triangle procedural eagle. It enters from the current camera's top-right boundary, swoops through a real directional-light shadow pass across the trailer roof, then circles with gentle banking and wing movement. Leaving and returning replays the entry. Follow Load / Whole Route use time-based camera damping. The requestAnimationFrame controller targets at most 60 renders per second, animates during dock-flag flutter, transit or camera settling, and suspends on hidden tabs. A Pause/Resume Motion button and static reduced-motion poses are included. Actual hardware frame rate is not guaranteed or measured.

The HUD, narrative and floating callout share the journey state. Counts update while pallets load/unload. Dock and receiver callouts use in-progress wording until the requested six-pallet and clean-POD terminal states are reached; the illustration never labels an unfinished POD as sent. Transit shows the requested BOL CONFIRMED / 68%, and delivery ends at 0 / 6 PALLETS / CLEAN POD SENT / 100%. The header percentage remains scroll progress. Fonts, including JetBrains Mono with its OFL notice, and all 3D assets are local. No blocking loading screen, remote model or runtime font request was added.

Rollback snapshot: `experiment-backups/before-eagle-20261024/` contains the entire previous `dist/`, package configuration and project notes. Restoring those copies returns the prior homepage; extra new, unreferenced modules/fonts can remain or be removed later. This is a local experiment, with no deployment or email sending.

Run `npm.cmd run check`, `npm.cmd run verify`, `npm.cmd run verify:stages` and `npm.cmd run verify:atlas`. The new verifier exercises 18,001 flight poses, 1,001 HUD/cargo states, 2,632 production scene frames at seven sizes, actual geometric shadow/roof intersections, flight re-entry, dry-van decals, dock shutters, camera toggles, pause, reduced motion, resource cleanup, and the production controller's 60fps scheduling cap/hidden-tab behavior. HTTP resources are checked separately. These use a renderer/DOM stub, not a real GPU. Browser inventory is empty and opening the in-app browser reports unavailable, so the eagle's appearance, text layout and actual GPU frame rate still need visual review. Earlier preview PNGs predate this experiment.

## Load lifecycle route - 24 October 2026

Open http://localhost:4185 and choose **Load lifecycle** to visit `/load-lifecycle/` in the same portfolio. Latest direction: keep this page clean and simple. It contains a small heading and seven stage titles, with one short action sentence each (57 action words in total). The long introduction, 24-item checklist, confirmation notes, sample messages and closing essay have been removed.

Keep the sticky vertical seven-stage sidebar, scroll-driven completion checkmarks and reduced-motion behavior. The Three.js/WebGL view has been enlarged and moved out of the sidebar: desktop widths above 1100px use progress, task text and a separate sticky scene column. At 1100px and below the scene sits inline below the heading, including on phones. The mobile progress list remains a numbered rail. Scrolling back resets completion. The concise layout uses a reading position that gradually moves lower while approaching the page end, so all seven stages can become active even on the shorter page. The stage links retain ordinary anchor targets, with enhanced scroll positioning so selecting a stage reliably starts its matching animation; selecting the current stage replays it. There are no forms, messages sent or shipment records updated; the footer identifies the workflow as illustrative.

Files: `dist/load-lifecycle/index.html`, `lifecycle.css`, `progress.js`, `progress-state.js`, `stage-motion.js` and `progress-scene.js`. Local fonts and the original Three.js truck models are reused. The homepage and original truck/trailer model files are unchanged. The enlarged stage view now plays a distinct finite 6-8.6 second sequence for each stage, with Play/Pause and Replay controls. It stops after the sequence, suspends when offscreen or the tab is hidden, and defaults to a final static pose for reduced motion. Explicit playback remains available.

Verification: project syntax and HTTP/fragment checks passed; seven titles and seven short actions remain; no checklist/notes/example-message markup remains; all seven stages activate and complete in four simulated viewport layouts, with reverse reset. The enlarged scene passes all-stage camera-fit checks at seven desktop, tablet, phone and short-window sizes (49 combinations). HTML structure, anchors and served resources also pass. Browser visual review is pending. See `design-qa.md` for prior revisions.

### Stage animations

- Load booked: dispatch sheet checks, envelope sent to the driver, acknowledgement.
- Truck dispatched: truck departure, rolling wheels/road and customer update.
- Checked-in shipper: backing into the pickup dock, arrival marker and check-in confirmation.
- Pickup & BOL reviewed: forklift/pallet loading, scanning the BOL, three review checks and a stamp.
- In transit: moving road/wheels, route checkpoints and customer update.
- At receiver: backing into the receiver, arrival marker and opening trailer doors.
- Delivered: forklift unloading, POD signature and delivery-confirmation stamp.

The paperwork, messages and freight remain illustrative geometry, with no sending or record changes. The visible page keeps its seven short actions. Document headings use local canvas textures; all models and runtime modules are local.

Run `npm.cmd run verify:stages` for seven distinct outcomes, 567 sampled animation poses, 1,029 camera projections, hitch/cargo/door checks, replay determinism and 28 stage-navigation targets. Actual playback code also passed a renderer-stub simulation for autoplay, pause, replay, finite stop, offscreen/tab suspension, reduced motion and disposal. These checks do not replace visual WebGL review; the browser inventory remains empty.

Progress saved for the next session on 2026-10-24. Start with [CHECKPOINT.json](CHECKPOINT.json) for the latest decisions, file map, constraints, verification results, and restart instructions. A timestamped project backup is stored in `D:/Ashish/output/logistics-checkpoints`.

A separate, local version based on the user's selected Route Atlas visual. The earlier portfolios and 3D experiments remain unchanged at ports 4182, 4183, and 4184.

Run `npm.cmd run dev` and open http://localhost:4185. No install or build is needed. Keep the preview running for the user's review.

The landscape is live Three.js geometry, not a hero image. Native page scrolling moves the original orange tractor and white reefer along a shared curved road, into pickup and delivery docks, and through loading and unloading. An orange road trace follows progress. The camera starts with an atlas overview and moves closer to the load. The Whole Route / Follow Load controls change the camera without resetting the load. The top route progress bar was removed at the user's request; the brand and compact progress readout remain in a shorter header.

Desktop text stays with its operational stage. Mobile uses a pinned 3D scene above naturally scrolling chapters. Scrolling backward rewinds the entire deterministic sequence. Reduced-motion preferences use discrete stage poses and instant navigation. Rendering is event-driven; there is no continuous animation loop.

The selected image is composition and art-direction reference only, saved under `references/selected-atlas.png`. It is not shipped as website artwork. Existing original procedural 3D truck and reefer assets are reused from our earlier experiment; the road, river, bridge, landscape and camera behavior are new. All JavaScript, Three.js, and IBM Plex fonts are local with their included MIT/OFL licenses.

This is an illustrative fictional load with six sample pallets. Status notes and paperwork labels demonstrate the workflow; they do not send messages, generate documents, or claim a real customer's activity. Personal claims use the supplied four years of US logistics experience and tracking/communication duties. No email sending, contact integrations, ownership disclosures, or deployment is included.

Files:

- `dist/index.html`, `atlas.css`, `atlas.js`: responsive page, chapters, native-scroll mapping and view controls.
- `dist/journey.js`, `route.js`: deterministic load timeline and shared road curve.
- `dist/landscape.js`, `world.js`: road, river, bridge, forest, yard, warehouses, cargo and forklift.
- `dist/scene.js`, `rig-models.js`: WebGL renderer, two camera modes and model assembly.
- `scripts/verify-journey.mjs`: 2,001 sampled positions, cargo/document states, continuity, exact hitch positions and cab/trailer clearance.

Use `npm.cmd run check` and `npm.cmd run verify`. Browser evidence and remaining visual differences are recorded in `design-qa.md`.

Readability revision: body copy is 16–17px, operational notes are 15–17px, and most supporting labels are 11–13px. Camera buttons have 44px hit areas. Larger notes sit above the truck on mobile. Narrow tablet chapters use natural scrolling to keep the larger copy accessible. Updated previews: `preview-readable-desktop.png` and `preview-readable-mobile.png`.
