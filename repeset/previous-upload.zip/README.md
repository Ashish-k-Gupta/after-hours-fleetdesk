# AFTER HOURS ? The Route Atlas

Private source backup for the interactive 3D fleet-support portfolio. Both deployment editions, local fonts, Three.js, and verification scripts are included.

## Run locally

Use Node.js 22 or newer. There are no external npm dependencies to install.

- Netlify edition: `npm run dev` ? http://localhost:4185
- Cloudflare edition: `npm run dev:cloudflare` ? http://localhost:4186
- Same Wi-Fi preview: `npm run dev:lan`

## Deployment folders

| Platform | Folder | Contact method |
| --- | --- | --- |
| Netlify | `dist/` | Netlify Forms with honeypot and Netlify-provided reCAPTCHA |
| Cloudflare Workers static assets | `cloudflare-dist/` | Direct email link |

The canonical editable website source lives in `dist/`. Run `npm run build:cloudflare` after changing it to regenerate the email-only Cloudflare edition. Deploy only the corresponding public folder.

For Netlify, enable form detection before deployment, configure submission notifications in the dashboard, and verify a hosted test submission. The local protected form snapshot is not a confirmation that those settings or that version are already live. See `netlify.toml` for build settings. For a manual Cloudflare static upload, select `cloudflare-dist/`.

## Validation

- `npm run check`
- `npm run verify`
- `npm run verify:stages`
- `npm run verify:atlas`
- `npm run verify:clearance`
- `npm run verify:inquiry`

## Project structure

- `dist/` ? HTML, CSS, JavaScript, procedural 3D geometry, fonts, and vendored Three.js.
- `cloudflare-dist/` ? generated email-only deployment snapshot.
- `scripts/` ? Cloudflare build and verification scripts.
- `server.mjs` ? local static preview server.

The daily FMCSA shortlist automation is a separate Google Apps Script project and is not part of this website backup. Outreach records, inbox screenshots, local notes, historic exports, and experimental backups are excluded.

Third-party license notices are retained under each edition's `vendor/` and `fonts/` folders.
