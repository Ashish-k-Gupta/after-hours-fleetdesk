# Route Atlas design QA — 2026-10-24

final result: passed

Passed for the authorized **interactive 3D adaptation** of the selected atlas direction. This is not a pixel-for-pixel reproduction of the generated illustration. The user specifically requested retaining the existing live 3D truck, pickup and delivery behavior. The source image is reference only and is not used as hero artwork.

## Evidence and normalization

- Visual target: `references/selected-atlas.png`, 1415 × 916 pixels. Removed the 31-pixel left and 14-pixel right outer dark margins for `references/selected-atlas-normalized.png`, 1370 × 916.
- Implementation: http://localhost:4185.
- Reference-size capture: `preview-reference-size.png`, browser CSS viewport 1370 × 916; captured image 1355 × 906. Normalized proportionally to 1370 × 916 in the comparison to account for the browser capture scale. No design elements were stretched separately.
- Full-view evidence: `comparison.png`, source left, implementation right, 2740 × 916.
- Focused typography evidence: `comparison-typography.png`, source left, implementation right. Compared title weight, wrapping, margins, body size, and scroll cue.
- Additional browser evidence: `preview-mobile.png` at CSS 390 × 844, captured 375 × 811; `preview-delivered.png` at CSS 1370 × 916, captured 1355 × 906; `preview-desktop.png` at the final normal browser size, CSS 1536 × 674. A 1536 × 730 desktop view was also tested.
- Both source and rendered images were opened together as composite comparisons before the final review. The final shorter-screen framing fix was checked in the browser and saved in `preview-desktop.png`.

## State and intentional differences

The selected image shows a pickup moment under the entry headline. The implemented page begins at the yard because the requested journey starts with a coupled truck and trailer. Native scrolling then reaches the pickup, transit, receiver and delivery states. The entry layout, brand, headline, cream background, green typography, orange accents, road, landmarks and callout treatment were compared. Loading and delivery were separately checked in their actual live states.

The warehouses, tree models, terrain and road use original procedural Three.js geometry. Their silhouettes and materials are simpler than the generated illustration. The moving camera and route geometry are adapted to accommodate the existing tractor/reefer and dock animation. These are intentional consequences of the user's live-3D requirement; the implementation does not claim illustration-level visual identity.

## Findings and fixes

No remaining actionable P0/P1/P2 findings for this adaptation.

Comparison history:

1. Initial browser pass found missing road surfaces, rounded hills, and geometry behind copy. Corrected road triangle winding, replaced the hills with triangulated terrain, and added screen-space compositing to preserve the reading area. The road and terrain are visible in the saved comparison; chapter text remains clear beside the dock scene.
2. Story copy could advance to the next chapter while the current load was still loading. Desktop copy now stays pinned to the active operational stage. Mobile retains natural chapter scrolling beneath the pinned scene. Checked loading at 38% with three pallets and the pickup chapter visible.
3. The first river placement crossed the receiver footprint. Moved the river/bridge and arranged the receiver farther along the route. Final delivery evidence shows the reefer at the receiving dock, clear of the river.
4. The first reference comparison showed lighter title weight, smaller type, and excess left inset. Added the matching locally available 700 font weight, adjusted the display size and left inset, and re-captured both full and focused comparisons.
5. Small secondary copy had insufficient contrast. Changed text to `#63735d` on `#f5f2e7` (4.52:1), darkened small orange labels, and used `#c06e40` for large emphasized words (3.38:1). Re-captured and compared.
6. A shorter desktop window clipped the starting truck. Added an aspect-dependent camera offset and adjusted the entry compositing fade so the complete coupled rig stays visible. Verified the resulting view at CSS 1536 × 674; saved as `preview-desktop.png`.

## Required fidelity surfaces

- **Typography:** local IBM Plex Sans 400/600/700, matching the selected design's broad sans serif direction and two-line headline. Comfortable body measures. Headline wrapping, type weight and supporting copy checked in the focused comparison. The generated image does not identify a specific font family; Plex is the project's existing family.
- **Spacing/layout:** open page-wide landscape, left reading area, slim route navigation, contextual notes, no containing scene card. Landscape remains pinned. Header, story and controls fit the desktop and mobile views without horizontal overflow. The complete route is available through the camera control.
- **Color/tokens:** warm cream, forest green, muted landscape, and copper accents retained. Secondary text contrast improved as noted above. This was a scoped readability check, not a complete WCAG audit.
- **Artwork:** actual WebGL truck, reefer, road, bridge, trees, terrain, warehouse docks, pallets and forklift. No rasterized hero substitute. The retained original model is used for both the scene and the small top-route truck render.
- **Copy:** selected entry headline and supporting message retained. Operational chapters explain tracking, communication and follow-through. Four years of experience comes from the supplied background. The illustrative load is clearly labeled; no customer results, contact details or employer ownership claims are invented.

## Interaction verification

- Stage links move through the native scroll timeline; no wheel/touch interception.
- Coupled rig at the yard; pickup approach, backing and loading.
- Partial cargo while loading; six pallets and BOL confirmed at departure.
- Curved-road travel; truck and reefer remain coupled.
- Receiver approach, backing and unloading; final state 100%, zero pallets, POD received.
- Reverse navigation restores the empty starting state.
- Both Whole Route and Follow Load controls change the view and preserve progress.
- Mobile navigation aligns the chapter beneath the pinned scene; scene top remains at 110 pixels while scrolling; no horizontal overflow.
- Browser console warnings/errors: none in the final captured session.
- `npm.cmd run check` and the 2,001-sample journey verifier passed. The verifier covers continuous poses, route progress, cargo/document states, exact hitch positions, door bounds and cab/trailer clearance.

## Follow-up polish and limits

P3: the generated illustration has more detailed vegetation, warehouse facades and terrain materials. The original procedural models are deliberately retained and can be detailed further in a later iteration. The top route labels are compact, especially on mobile. Reduced-motion and WebGL-failure branches are implemented but were not exercised by changing operating-system/browser preferences in this session. Browser coverage is Chrome desktop with responsive viewport testing, not physical-device testing.

Implementation checklist: complete for this local prototype. Earlier versions remain available; no deployment or communications were performed.

## Approved header removal

The user subsequently requested removing the miniature top truck, route line, and Yard / Pickup / In Transit / Delivery labels. Removed that entire route navigation component, its scroll-update bindings, and the unused miniature renderer. Kept the main 3D journey and shortened the header to 80px desktop / 72px mobile. The original reference comparison above documents the earlier version and is superseded for this header area by the user's removal request.

Scoped verification passed: syntax check; browser confirmation that the route component is absent; main scene renders; scroll cue reaches pickup at 16% with the appropriate status; no browser warnings/errors; mobile header is 72px with no horizontal overflow. New desktop evidence: `preview-header-updated.png`. Temporary mobile viewport override was reset. No changes were made to the earlier sites.

## Approved readability revision

The user found the supporting type too small. Increased body copy to 16–17px, work notes to 15–16px, scene notes to 15–17px, and most labels/captions to 11–13px. Increased camera button hit areas to 44px. Added space around the text, allowed two chapter headings to wrap into fewer lines on wide screens, and moved mobile notes above the vehicle so the enlarged text does not cover it. Camera controls have a light backing for contrast over scenery. Notes have a stable width to prevent size changes as they reposition.

Scoped verification passed: the longest desktop chapter fits at 1536 × 674 (active copy bottom 517px); the normal 1920 × 889 view was inspected; 390 × 844 mobile text and notes were visually checked; 320px and 800px layouts report no horizontal overflow. The 800px layout uses normal chapter flow rather than clipped fixed text. JavaScript syntax check passed. The 3D scroll states remain active. Evidence: `preview-readable-desktop.png`, `preview-readable-mobile.png`. Mobile evidence uses a page-coordinate clip of the visible viewport because the browser's ordinary emulated capture was scaled into a thumbnail. The viewport override was reset before handoff.

The original image comparisons above are historical art-direction evidence; the user's newer readability request supersedes the original small typography.
