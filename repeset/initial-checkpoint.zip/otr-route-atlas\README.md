# After Hours — The Route Atlas

Progress saved for the next session on 2026-10-24. Start with [CHECKPOINT.json](CHECKPOINT.json) for the latest decisions, file map, constraints, verification results, and restart instructions. A timestamped project backup is stored in `D:/Ashish/output/logistics-checkpoints`.

A separate, local version based on the user's selected Route Atlas visual. The earlier portfolios and 3D experiments remain unchanged at ports 4182, 4183, and 4184.

Run `npm.cmd run dev` and open http://localhost:4185. No install or build is needed. Keep the preview running for the user's review.

The landscape is live Three.js geometry, not a hero image. Native page scrolling moves the original orange tractor and white reefer along a shared curved road, into pickup and delivery docks, and through loading and unloading. An orange road trace follows progress. The camera starts with an atlas overview and moves closer to the load. The Whole Route / Follow Load controls change the camera without resetting the load. The top route progress bar was removed at the user's request; the brand and compact progress readout remain in a shorter header.

Desktop text stays with its operational stage. Mobile uses a pinned 3D scene above naturally scrolling chapters. Scrolling backward rewinds the entire deterministic sequence. Reduced-motion preferences use discrete stage poses and instant navigation. Rendering is event-driven; there is no continuous animation loop.

The selected image is composition and art-direction reference only, saved under `references/selected-atlas.png`. It is not shipped as website artwork. Existing original procedural 3D truck and reefer assets are reused from our earlier experiment; the road, river, bridge, landscape and camera behavior are new. All JavaScript, Three.js, and IBM Plex fonts are local with their included MIT/OFL licenses.

This is an illustrative fictional load with six sample pallets. Status notes and paperwork labels demonstrate the workflow; they do not send messages, generate documents, or claim a real customer's activity. Personal claims use the supplied four years of US logistics experience and tracking/communication duties. No email sending, contact integrations, ownership disclosures, or deployment is included.

Files:

- `dist/index.html`, `atlas.css`, `atlas.js`: responsive page, chapters, native-scroll mapping and view controls.
- `dist/journey.js`, `route.js`: deterministic load timeline and shared road curve.
- `dist/landscape.js`, `world.js`: road, river, bridge, forest, yard, warehouses, cargo and forklift.
- `dist/scene.js`, `rig-models.js`: WebGL renderer, two camera modes and model assembly.
- `scripts/verify-journey.mjs`: 2,001 sampled positions, cargo/document states, continuity, exact hitch positions and cab/trailer clearance.

Use `npm.cmd run check` and `npm.cmd run verify`. Browser evidence and remaining visual differences are recorded in `design-qa.md`.

Readability revision: body copy is 16–17px, operational notes are 15–17px, and most supporting labels are 11–13px. Camera buttons have 44px hit areas. Larger notes sit above the truck on mobile. Narrow tablet chapters use natural scrolling to keep the larger copy accessible. Updated previews: `preview-readable-desktop.png` and `preview-readable-mobile.png`.
