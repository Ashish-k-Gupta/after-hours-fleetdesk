import http from "node:http";
import {readFile,stat} from "node:fs/promises";
import {dirname,extname,resolve,sep} from "node:path";
import {fileURLToPath} from "node:url";
const root=resolve(dirname(fileURLToPath(import.meta.url)),"dist");
const port=Number(process.env.PORT||4185);
const types={".html":"text/html; charset=utf-8",".js":"text/javascript; charset=utf-8",".css":"text/css; charset=utf-8",".woff2":"font/woff2",".txt":"text/plain; charset=utf-8"};
http.createServer(async(req,res)=>{
  try{
    if(!["GET","HEAD"].includes(req.method)){res.writeHead(405,{Allow:"GET, HEAD"});return res.end("Method not allowed");}
    let path=resolve(root,`.${decodeURIComponent(new URL(req.url,"http://localhost").pathname)}`);
    if(path!==root&&!path.startsWith(root+sep)){res.writeHead(403);return res.end("Forbidden");}
    if((await stat(path)).isDirectory())path=resolve(path,"index.html");
    const data=await readFile(path);res.writeHead(200,{"Content-Type":types[extname(path)]||"application/octet-stream","Cache-Control":"no-cache","X-Content-Type-Options":"nosniff"});res.end(req.method==="HEAD"?undefined:data);
  }catch{res.writeHead(404,{"Content-Type":"text/plain; charset=utf-8"});res.end("Not found");}
}).listen(port,"127.0.0.1",()=>console.log(`After Hours / The Route Atlas: http://localhost:${port}`));
