# After Hours — The Route Atlas

## Cloudflare email-only upload - 25 October 2026

**Live deployment verified:** https://route-atlas.afterhours-fleetdesk.workers.dev/ now serves this edition. Cloudflare shows version 5f7459cd Ready at 100% traffic; prior version 9c1d8559 remains in deployment history. The user completed the upload after the browser upload tool continued rejecting local-file access, and Cloudflare deployed automatically. Actual Brave desktop and 390x844 mobile checks confirm email-only contact, correct mailto, zero fields/POST forms/submission script, latest coverage wording, actual 3D canvas/ready state and hidden loader, with no captured console errors. Mobile dialog client/scroll width both 335px; viewport reset. Proof: preview-cloudflare-deployed-email-desktop.png and preview-cloudflare-deployed-email-mobile.png.

Current Cloudflare upload: **after-hours-cloudflare-email-only.zip** (573,243 bytes, 31 public files), or **D:/Ashish/otr-route-atlas/cloudflare-dist**. This is a separate generated edition of the latest local site. The existing dist directory remains the Netlify form/CAPTCHA edition. Do not upload dist when you want this Cloudflare email-only version.

The contact dialog now displays afterhours.fleetdesk@gmail.com with a Fleet coverage mailto subject, weekend/after-hours wording and a short prompt to include fleet size, coverage days/hours and time zone. No inquiry inputs, submit button, CAPTCHA, provider registration or submission script is included. The tiny native method=dialog form only implements the close button; it sends no data. All three Discuss your coverage buttons still open the same dialog. Closing the dialog and Escape restore the story normally.

All latest scene files, flags, road/camera fixes, experience copy and non-blocking 3D startup loader are included. The generated files match dist byte-for-byte except index.html and the small email-dialog CSS addition; inquiry.js is omitted. The source Netlify form and its tests are preserved.

Regenerate with npm.cmd run build:cloudflare. This script safely replaces only the generated cloudflare-dist directory, validates the contact replacement, and verifies all other files match the latest dist source. Preview with npm.cmd run dev:cloudflare at localhost:4186; the existing localhost:4185 preview still serves dist. No dependency installation or application build is required.

Validation: build generation, syntax checks and existing inquiry harness pass. All 31 public resources were fetched from the Cloudflare preview and compared with source bytes; inquiry.js/private notes returned 404, POST returned 405, and the unchanged Netlify preview retained its form. Actual Brave desktop and 390x844 phone-sized contact dialogs checked: no fields, valid mailto href, no horizontal overflow and no captured console errors. The actual 3D scene reached ready and hid its loader. Close button and Escape tested; viewport reset. Proof: preview-cloudflare-email-only-desktop.png and preview-cloudflare-email-only-mobile.png. The temporary Cloudflare preview is stopped after QA; the existing 4185/LAN previews are retained.

The ZIP contains root index.html and normalized forward-slash paths; every archived entry SHA-256 matches cloudflare-dist. No private notes, server scripts, backups or resume files are included. Upload it to the existing route-atlas Cloudflare Worker so the URL remains https://route-atlas.afterhours-fleetdesk.workers.dev/. The package is now deployed through the user-completed Cloudflare upload; see the live-verification note above.

## Additional form spam protection - 24 October 2026

Current local upload: **after-hours-netlify-protected.zip** (576,117 bytes, 32 public files; root index, forward-slash web paths and every source SHA-256 verified), or the current dist folder. This supersedes after-hours-netlify.zip for future uploads. The protected build has NOT been deployed by the agent. The previously deployed form still has the successful pre-CAPTCHA setup-test evidence recorded below.

Existing Netlify Akismet filtering and the registered bot-field honeypot remain. Added Netlify-provided reCAPTCHA 2 using data-netlify-recaptcha on the form and one empty widget div. Compact size is requested for narrow phones. Netlify supplies the actual widget and server-side verification during deploy; no custom site/secret keys or SMTP setup are required. AJAX forwards g-recaptcha-response. Missing/expired/unloaded challenges stop the client request with a clear direct-email fallback. Tokens are reset after each network attempt because they expire and are single use. HTTP redirects fail closed so a rejected challenge redirected back to the page cannot be mistaken for a successful HTTP 200.

This is additional bot verification, not a strict per-IP submission quota. Browser-only cooldowns are bypassable and were not presented as protection. Netlify code-based limits are supported on functions/edge functions/redirects, but this project currently uses manual static-folder Drop and native Forms. A server-enforced submission quota would require a separately designed endpoint/deployment path; rate rules have NOT been added or claimed here. CAPTCHA cannot guarantee that all spam stops.

Verification: syntax and verify:inquiry pass, including token forwarding, missing/unloaded/expired challenges, renewal after failure, redirect rejection, reset failures, existing validation/HTTP/offline/timeout recovery and duplicate prevention. All CAPTCHA and fetch behavior in the harness is mocked; it does not verify Google's token validation or Netlify enforcement. Actual Chrome local desktop and 390x844 layout reviewed with no captured console errors and no horizontal modal overflow. Viewport reset. Localhost remains non-sending; no CAPTCHA is rendered there and no new real inquiry was submitted this turn. Proof: preview-spam-protection-local.png and preview-spam-protection-mobile-local.png. Actual injected widget, compact layout and valid/invalid-token hosted behavior require verification after user redeployment. Google CAPTCHA adds third-party script/network work; no physical-phone performance claim is made.

Next: upload the updated dist folder to Netlify with form detection enabled. Confirm the CAPTCHA appears in the contact dialog and the Forms page shows the added protection. Complete a normal human challenge and send one test; confirm acceptance, Netlify record and Gmail receipt. The agent must not solve a CAPTCHA without the required action-time confirmation. Keep the direct email fallback available.

References: https://docs.netlify.com/manage/forms/spam-filters/ , https://docs.netlify.com/manage/security/secure-access-to-sites/rate-limiting/ , https://developers.google.com/recaptcha/docs/display , https://developers.google.com/recaptcha/docs/verify .

## Netlify Forms deployment - 24 October 2026

**Live verification update:** The user redeployed after enabling Netlify detection. Actual Chrome now shows processed registration and enabled Send. One clearly labeled After Hours setup test was submitted using the business email; the live form returned success, cleared inputs and restored controls with no console errors. The user screenshot confirms Gmail notification settings. Inbox receipt and the Netlify submission record have not been checked. Proof: preview-netlify-live-submission-success.png.

Current hosting choice is Netlify. This supersedes the Cloudflare/FormSubmit instructions recorded below. Use **after-hours-netlify.zip** (575,810 bytes; 32 public files), or deploy the dist folder. The ZIP contains root index.html, forward-slash web paths and every entry matches its source SHA-256. It includes the latest 3D loader, weekend/after-hours copy, flags and road/camera fixes. Only public site files are included.

The static after-hours-inquiry form now has data-netlify="true", the form-name field, a subject field and a bot-field honeypot. JavaScript posts application/x-www-form-urlencoded data to the same-origin root path. The email field supplies the visitor's reply address to Netlify notifications. FormSubmit requests, JSON envelopes and recipient activation are removed. Existing required/email/length/fleet-size validation, pending-state feedback, duplicate prevention, 20-second timeout, failed-input preservation and direct email remain.

Deploy and activate:

1. In your Netlify project, open Forms and enable form detection. Upload/redeploy after enabling it, even if you uploaded this ZIP once already.
2. Upload after-hours-netlify.zip (or dist) through the manual deployment area. Confirm Forms lists after-hours-inquiry after the deploy finishes. With Git instead, the included netlify.toml sets publish=dist and command=npm run check.
3. Under Forms > Submission notifications, add an email notification for after-hours-inquiry to afterhours.fleetdesk@gmail.com. The recipient is configured in Netlify, not supplied by a public form field. No Gmail password or SMTP setup is needed.
4. Submit one clearly labeled setup inquiry on the deployed HTTPS page with a valid email. Confirm the submission in Netlify, then check the business Gmail Inbox and Spam, fields and Reply-To. An accepted website submission alone does not prove inbox delivery.

The client stays non-sending on localhost/private-IP/non-HTTPS pages and when registration attributes remain in the HTML. Netlify removes those attributes during form processing; a registered Netlify deploy enables Send. If the hosted button remains disabled, enable form detection and redeploy, then refresh.

Validation: npm run check and verify:inquiry pass. Mocked tests cover processed/unprocessed registration, HTTPS/private previews, validation, Unicode and special characters, same-origin URL encoding, HTML success responses, HTTP errors, offline/timeout recovery, duplicate prevention, honeypot and labels. Chrome local dialog opens, shows the preview-only note, and has no captured console errors. Proof: preview-netlify-form.png. No actual Netlify deployment, form registration, notification configuration or Gmail receipt has been verified by the agent.

Official references: https://docs.netlify.com/manage/forms/setup/ and https://docs.netlify.com/manage/forms/notifications/.

## Mobile 3D loading feedback - 24 October 2026

Latest upload: **`after-hours-cloudflare-loader.zip`**, 575,813 bytes, 32 public files. Includes the new loading indicator plus all weekend/after-hours copy, FormSubmit integration, flags and road/camera fixes. Forward-slash ZIP paths, root index and SHA-256 of every public file are verified. The latest archive still needs a Cloudflare upload; actual inquiry activation/inbox verification remains pending.

The scene now shows a small branded, indeterminate loading indicator immediately from static HTML. It is confined to the 3D panel, so the offer, scrolling and contact dialog remain usable. It changes from Loading the 3D route to Preparing the 3D scene after imports resolve, gives the browser a paint opportunity before synchronous scene construction, and disappears only after the first successful renderer frame. Error states hide the indicator and show the existing readable fallback. Empty-scene camera/HUD controls stay hidden and inert until ready. A long-start notice appears after 10 seconds; there is no fake completion percentage or forced minimum display duration. Reduced motion disables its decorative animation.

Module preload hints start the scene and both Three.js engine files earlier, removing part of the dynamic-import download chain. Engine files total 2,120,885 bytes on disk before transport compression. This is not a measured transfer size on the user's phone. Network fetches, JavaScript/geometry work and GPU/shader preparation can each contribute to startup; actual phone bottleneck/timings have not been profiled.

Verification: syntax and the existing scene/controller suite pass (6,146 scene frames at seven sizes). Added checks cover loader persistence before a frame, readiness/busy/focus state after the first render, failure fallback and timer cleanup. In actual Chrome, a temporary localhost:4186 server deliberately delayed scene.js for 14 seconds: both desktop and 390 x 844 phone views showed the indicator, the coverage dialog stayed usable during the delay, and successful rendering removed it with aria-busy=false. No console errors were captured. The temporary server was stopped, its tab closed, viewport reset, and the normal localhost:4185 preview reloaded and retained.

Proof: `preview-scene-loading-mobile.png`, `preview-scene-loading-desktop.png`, and `preview-scene-loaded.png`. These are controlled slow-start demonstrations, not measurements of a real 4G/5G device. Files changed: `dist/index.html`, `dist/atlas.css`, `dist/atlas.js`, and `scripts/verify-atlas-enhancements.mjs`.

## Weekend / after-hours inquiries - 24 October 2026

Prior package: **`after-hours-cloudflare-inquiries.zip`**, 574,910 bytes, 32 public files with verified web paths and source hashes. Its state flags, road/camera fixes, weekend and after-hours positioning, and FormSubmit inquiry implementation are included in the latest loader ZIP above. Actual email delivery still needs activation and verification.

The live URL is confirmed as https://route-atlas.afterhours-fleetdesk.workers.dev/. The browser currently shows the older service wording/form there. The latest local copy explicitly offers weekend and after-hours tracking, driver follow-ups and broker updates to US fleets with 5-15 trucks. The current-employment note still avoids the confidential employer and agrees coverage in advance; no hours or 24/7 availability were invented.

`dist/inquiry.js` posts JSON to `https://formsubmit.co/ajax/afterhours.fleetdesk@gmail.com` only after a valid submission on a public HTTPS page. It sends the visitor email as Reply-To, a fixed coverage subject, table layout and the documented `_honey` field. No visitor autoresponse, extra recipients, passwords, secret keys or explicit CAPTCHA-disabling override were added. Localhost, private-IP and non-HTTPS previews remain non-sending. Netlify registration attributes are removed; `netlify.toml` is only optional static-host configuration now.

The client requires an explicit provider success value, checks activation messages even when HTTP status is 200, preserves failed/pending inputs, prevents duplicate clicks, and restores the form after rejection, malformed JSON, network errors or a 20-second timeout. A submitted status means the provider accepted the request; it does not prove Gmail inbox delivery.

Activation and live test:

1. Upload the latest ZIP to the existing `route-atlas` Cloudflare Worker and hard-refresh the public site. Confirm the hero says WEEKEND & AFTER-HOURS SUPPORT.
2. Open Discuss your coverage and submit a clearly labeled setup test using a valid email address. For a self-test, use `afterhours.fleetdesk@gmail.com`, Name `After Hours setup test`, and message `SETUP TEST - checking weekend and after-hours inquiries.` Fleet size can be empty.
3. If FormSubmit sends a confirmation to that Gmail inbox, click Activate Form. Check Spam too. The form preserves the setup-test fields if activation is pending; submit again after confirming.
4. Verify the actual inquiry notification in Gmail, its fields and Reply-To. Do not treat the website success message alone as delivery proof. No real form submission or activation email was sent by the automated tests.

`npm.cmd run check` and `npm.cmd run verify:inquiry` pass. The harness mocks provider requests and covers Cloudflare/local/protocol gating, invalid Email `Doe`, validation, JSON and fixed recipient, explicit success, activation, HTTP-200 rejection, invalid JSON, HTTP errors, offline, timeout, duplicate prevention and recovery. Actual desktop Chrome preview and the scrollable 390 x 844 phone modal were checked; no horizontal overflow. Browser access briefly interrupted, then recovered with a fresh tab; the viewport override was reset. Proof: `preview-weekend-inquiry-form.png` and `preview-weekend-inquiry-mobile.png`. The connected Gmail account is not the business recipient; do not read that unrelated inbox for activation.

Provider references: https://formsubmit.co/documentation and https://formsubmit.co/ (first-use recipient confirmation). Real activation and Gmail receipt remain pending user action.

## State flags, road clearance and ground flicker - 24 October 2026

Latest upload: **`after-hours-cloudflare-updated.zip`**, 574,707 bytes, 32 public files. This includes the California flag at the shipper, New York state flag at the receiver, terrain and camera fixes, and HUD clearance. It supersedes both earlier upload archives. Entry paths use forward slashes; every archived file's SHA-256 matches `dist`. The ZIP has not been uploaded to the existing Cloudflare Worker yet.

The existing US flag stays at the shipper, with California beside it on a slightly shorter pole. New York marks the delivery facility. State artwork is a small, locally drawn, stylized flag texture: California's bear, star, red stripe and legend; New York's blue field, eagle/globe, Hudson shield, Liberty/Justice and current two-line motto. No external model, image or font requests were added. Both use the existing low-poly cloth mesh and shared animation loop. The receiver now offers Pause/Resume Motion too; reduced motion, dialog pause, hidden-tab suspension and Experience rendering suspension remain supported. Design references: https://capitolmuseum.ca.gov/state-symbols/flag/ and https://www.nysenate.gov/legislation/laws/STL/70.

The reported clipping at about 66% was caused by coarse hill triangles rising into the asphalt. The terrain generator now reserves clearance around the curved road, including a buffer for triangle interpolation. The flashing receiver patches were depth fighting between the flat hill vertices and the base ground, both formerly at -0.25. The base is now at -0.5, below all terrain. Road, shoulder, markings and dock aprons remain at their original heights.

The floating callout now uses the projected bounds of the complete tractor and trailer, choosing a clear position and avoiding camera/motion controls. Mobile framing reserves room above the rig for the card. The camera keeps up with moving load positions and resets its framing after large scroll jumps; camera-mode transitions still damp. Whole Route now fits both facilities and the complete driving path at wide and narrow aspect ratios.

Verification: syntax check, 6,146 production scene frames at seven sizes, full forward/reverse callout and camera checks, Whole Route dock/load fit checks, and 39,021 road-shoulder/tire samples across 2,001 poses pass. Terrain checks raycast actual interpolated triangles, and base-ground separation has a regression assertion. Actual Chrome forward/reverse desktop scrolling, both camera modes and phone-sized views were reviewed with no console errors. Phone emulation used a 390 x 844 viewport (375 CSS content width); no physical-device or FPS benchmark is claimed.

Evidence: `preview-truck-clearance-fixed.png` (the reported 66% bend), `preview-california-state-flag.png`, `preview-receiver-state-flag.png`, `preview-whole-route-fixed.png`, and `preview-mobile-route-fixed.png`. Run `npm.cmd run verify:clearance` for terrain/ground checks and `npm.cmd run verify:atlas` for geometry, cameras and overlay clearance.

## Cloudflare Pages upload - 24 October 2026

The user selected Cloudflare hosting with no credit card. This supersedes the earlier Netlify hosting choice. The user deployed the site as a Worker at https://little-violet-bc2a.afterhours-fleetdesk.workers.dev/.

**Use the latest `after-hours-cloudflare-updated.zip` described above.** The first replacement was `after-hours-cloudflare-fixed.zip`; it corrected the original PowerShell `Compress-Archive` ZIP's nested backslash paths. On the first live deployment, browser logs showed the dynamic scene import failed and the observed nested font asset returned HTTP 404. The fallback message incorrectly suggested enabling WebGL.

The corrected ZIP explicitly uses forward slashes, contains exactly 32 public files with root `index.html`, is 571,634 bytes, and has verified source SHA-256 hashes for every entry. Both `vendor/three.module.js` and `vendor/three.core.js`, nested fonts and the Load lifecycle page have exact web paths. Create future ZIP entries with `System.IO.Compression.ZipFileExtensions.CreateEntryFromFile` and entry names normalized using `.Replace('\', '/')`; load both `System.IO.Compression` and `System.IO.Compression.FileSystem` assemblies. Do not use Windows `Compress-Archive` for this upload. No project notes, backups, server code or resume files are included.

The local 3D scene now has actual Chrome screenshot evidence at `preview-cloudflare-fix-local.png`, with a visible canvas, hidden fallback and no console errors after reload. Atlas geometry/controller verification passes. The corrected archive has not yet been uploaded to the live Worker. The generic fallback now asks visitors to reload instead of assuming WebGL is disabled.

1. Create a free Cloudflare account at https://dash.cloudflare.com/ and verify the email.
2. Open Workers & Pages, then Create application, Get started under Pages, and Drag and drop your files.
3. For a new Pages project, use `afterhours-fleetdesk` if available and upload the corrected ZIP above. The user's existing Worker can instead be updated with this same static archive.
4. Select Deploy site / Save and Deploy. Use the actual returned `pages.dev` address; it has not been reserved or verified yet. No purchased domain or local server is needed to keep the deployed site online.
5. Check the homepage, Experience section and Load lifecycle link on a phone. For later updates, create a new deployment in the same Pages project using a fresh archive of `dist`.

The current form still uses Netlify-specific handling and remains unavailable on Cloudflare. Visitors can use the direct `afterhours.fleetdesk@gmail.com` email link. Before describing inquiry delivery as active, connect a Cloudflare-compatible form handler/email service and verify a hosted submission in Gmail. No messages have been sent. The public ZIP deliberately preserves this non-sending state instead of reporting a false success.

Official upload instructions: https://developers.cloudflare.com/pages/get-started/direct-upload/. A Direct Upload project cannot later be converted to Git integration; automatic Git deployments would require a new project. Dashboard drag and drop accepts this ZIP; it does not compile a Pages `functions` directory.

## Same-Wi-Fi preview - 24 October 2026

A LAN preview is running at http://192.168.1.10:4185 on the Wi-Fi 2 interface. Share this address with phones on the same network and keep the computer awake. This is a local network preview, not an internet deployment. The existing http://localhost:4185 preview remains running separately.

Restart LAN sharing with `npm.cmd run dev:lan` from this directory. The server automatically selects an available private IPv4 Wi-Fi address, falling back to a private wired interface, and prints the current URL. The address may change when reconnecting to Wi-Fi. It binds only that specific address; ordinary `npm.cmd run dev` continues to bind 127.0.0.1. Only dist is served, with GET/HEAD; private project/server files and traversal are blocked. The inquiry form recognizes private-IP previews and stays in non-sending mode.

Verification: current LAN URL and loopback serve identical HTML; seven page/scene/font/form resources return HTTP 200; HEAD works; private source paths/traversal fail and POST returns 405. Syntax and inquiry tests pass. Separate listeners were confirmed on 127.0.0.1 and 192.168.1.10. Actual access from a second physical device is not verified; Windows Firewall or router client isolation can still affect it. No firewall or router settings were changed.

## Inquiry form / Netlify - 24 October 2026

The user originally selected Netlify, then switched to Cloudflare Pages; the following records the existing Netlify-specific form implementation, not the current deployment plan. The three Discuss your coverage buttons open a shared form with Name, Email, optional Fleet size and What coverage do you need? The direct afterhours.fleetdesk@gmail.com mailto remains below it. The native dialog is wider, scrollable on small/short screens, with 16px inputs, visible labels/hints, a persistent close control and feedback for submission status. The form module is independent of the 3D scene. Existing modal pause/resume behavior is unchanged.

Implementation: dist/inquiry.js handles trimmed/required fields, browser email validity, optional integer fleet sizes from 1-999, bounded input lengths, a honeypot, one submission at a time, a 20-second timeout, and URL-encoded posting to Netlify. Success is shown only after an accepted response; failures retain the message. No local storage, lead uploads, newsletter subscription or auto-reply was added. On localhost, HTTP or an unregistered form, Send inquiry is disabled with an honest availability note; visitors can use the direct email link. The local static server continues to reject POST with 405.

**Delivery is not activated or verified yet.** The site remains local-only. netlify.toml prepares a static deployment of dist with npm run check. The form is named after-hours-inquiry. Netlify post-processing removes the registration attribute, which the client uses to enable sending on the deployed HTTPS site.

Before outreach, finish these Netlify steps:

1. Open this portfolio's Netlify project, go to Forms and enable form detection. Deploy/redeploy the current dist folder, or connect this repository using netlify.toml. This must be a separate project from the earlier developer portfolio unless the user explicitly chooses otherwise.
2. Confirm after-hours-inquiry appears in Forms.
3. In Forms > Submission notifications, add an email notification for after-hours-inquiry addressed to afterhours.fleetdesk@gmail.com. The recipient is set in Netlify, not by HTML or netlify.toml.
4. Submit a clearly labeled test on the hosted site, confirm it in Netlify's verified submissions, and confirm receipt in the Gmail inbox. A form success message alone does not confirm inbox delivery. No real message was sent by the implementation tests.

References: [Netlify form setup](https://docs.netlify.com/manage/forms/setup/), [email notifications](https://docs.netlify.com/manage/forms/notifications/) and [honeypot support](https://docs.netlify.com/manage/forms/spam-filters/).

Checks: npm run check, verify:atlas and verify:inquiry pass. The inquiry harness stubs fetch and covers local/unregistered/HTTP gating, trimming, required/email/fleet-size/length checks, URL encoding, metadata, success, HTTP errors, rate limiting, offline, timeout, retry preservation, duplicate prevention, busy-state recovery and honeypot handling. Served HTML and runtime checks pass; previous company/date/current-status/name-removal/fleet-size/contact choices are preserved. No live Netlify project URL was provided and no new deployment was performed, so external form registration and email receipt remain pending. Actual browser visual review remains pending too.

Files: dist/index.html, atlas.css, inquiry.js, netlify.toml, package.json and scripts/verify-inquiry.mjs. Before-change snapshot: experiment-backups/before-inquiry-form-20261024-163845/.

## I-40 scenery and parked fleet - 24 October 2026

Added three static, procedural landmarks to the route: a double-arch bridge inspired by the I-40 Hernando de Soto bridge at Memphis; Groom's leaning Britten water tower; and Cadillac Ranch with ten nose-down, finned cars. The route is explicitly an I-40-inspired miniature, with compressed westbound ordering: Memphis, Groom, Amarillo. A small I-40 WEST marker reinforces the setting. This is an illustrative load, not a geographically accurate navigation map. The existing moving truck, eagle, loading/unloading and camera modes are preserved.

The yard now has five complete, coupled parked rigs in muted colors, replacing three empty parked trailers. Their positions leave the yard office, an interior aisle and the active truck's highway departure clear. Repeated chassis, tires, body panels, trailer ribs, fence posts and parking guides are instanced by primitive/material. All new scenery is static; there are no new animation loops or external image/model/font downloads.

Measured against the saved pre-change landscape: raw JavaScript growth is 11,743 bytes (3,624 bytes when gzip-compressed); base generated-texture pixel memory grows by about 1.31 MiB. Static landscape drawable objects decrease from 114 to 106 after batching. Landscape triangles increase from 18,724 to 31,730. These are scene-inventory and code-size measurements, not actual GPU draw counts, download timings or device FPS. See scenery-performance.json. No 60fps hardware guarantee is made.

Source files: dist/scenery-batch.js, dist/parked-fleet.js and dist/i40-landmarks.js, integrated through dist/landscape.js. The earlier landscape, scene, page and project notes were copied to experiment-backups/before-i40-scenery-20261024-161431/.

Checks: syntax, 2,001 original journey poses, seven lifecycle outcomes and the extended atlas scene/controller verification pass. New scene checks confirm all three landmarks enter the following camera at seven sizes, stay on the visible side of the desktop reading mask, and leave the real eagle-to-trailer shadow path clear. Parking bounds and instance geometry/matrices were checked for finite values and office/parking/exit clearance. Eight page/runtime/lifecycle resources return HTTP 200. All six separate lifecycle files are unchanged. Actual WebGL appearance and physical-device FPS still need browser review.

Landmark references: Amarillo Convention & Visitors Bureau, https://www.visitamarillo.com/blog/post/cadillac-ranch/ ; Texas Highways (Texas Department of Transportation), https://texashighways.com/travel/roadside-oddity-the-leaning-tower-of-texas-britten/ ; University of Memphis, https://classic.memphis.edu/uofmmagazine/publications/2021/fall2021/bridge.php ; TDOT bridge report, https://www.tn.gov/content/dam/tn/tdot/i55-bridge-/MSRiver%20Bridge%20Final%20Report%20202310.pdf . These informed the models and are not fetched by the website at runtime.

## Experience section - 24 October 2026

Selected logistics experience follows delivery and precedes the footer: http://localhost:4185/#experience. The user clarified that Quality Enterprise was the employer managing the Laut assignment in India, and confirmed November 2022-August 2023 for both. The duplicate Laut entry and Quality duties are merged under Quality Enterprise - Dispatch Executive, with long-haul tracking/tracing, driver follow-ups, customer/client email communication, status enquiries and after-hours updates. The Quality Enterprise entry explicitly identifies Laut Transportation Inc., FBT Inc. and Harrison Transportation Inc. as the carrier businesses whose dispatch and tracking operations were supported. These are past carrier assignments through Quality Enterprise, not separate employers. A Current status note above the dated roles now states that the user is currently employed and offers independent part-time/weekend OTR support through After Hours, with coverage agreed in advance. The current employer is omitted from the public page; its identity has not been supplied and must not be requested or inferred. The public section contains two past roles: Quality Enterprise and Sigea Solutions (February-November 2022). Sigea duties, the four-year overall experience statement and the confirmed shift rotation remain. No visible personal name, Patiala location, current-employer claim or NDA disclosure is shown. This clarification supersedes the older version on port 4182.

The section uses the existing cream/forest/terracotta palette, a two-column editorial history on desktop and a single column at 800px and below. It is ordinary scrolling content, outside the four load-story chapters. Its employment-context note distinguishes these roles from the separate part-time/weekend service. The user's visible personal name stays removed, fleet size remains 5-15 trucks, and the supplied business email is preserved. No employer logos, new testimonials, carrier records or resume download were added.

Experience links are available in desktop navigation, the introductory four-year note and delivery closeout. A third Discuss your coverage button appears at the end of the history and opens the same email dialog. When the history reaches the header, the fixed scene and fixed story text become hidden; scene controls become inert and WebGL frames stop. Returning to the journey restores them. The header status/link follows the reading mode. The original journey progress ends at delivery and stays at 100% throughout the history, rather than stretching the route across the added text.

Verification: npm run check and verify:atlas pass. The production-controller harness additionally verifies desktop/mobile experience anchor positions, scene hiding/inert state, idle rendering, returning to the yard, legacy delivered links and reduced-motion navigation. Current served HTML checks confirm two selected past roles, merged Quality duties, confirmed dates/rotation, unique IDs and valid local anchors, three contact triggers, preserved fleet size/email and no visible personal name or previously excluded role/relationship details. The homepage and runtime/lifecycle resources return HTTP 200. These checks do not replace a real browser visual review, which remains pending. The preceding HTML, CSS, controller and project notes are copied in experiment-backups/before-experience-20261024-160445/.

## Service summary and contact action - 24 October 2026

The homepage now states the service and audience near the hero: tracking, driver follow-ups, broker updates and after-hours support for US fleets with 5-15 trucks. A forest-green Discuss your coverage button appears beside the journey link and again at delivery closeout. Both open one native, keyboard-accessible dialog with the user-provided business email afterhours.fleetdesk@gmail.com. The email link opens a mail draft addressed to that account with the subject Fleet coverage. The coming-soon placeholder has been removed. The shared coverage panel now contains a Netlify Forms inquiry form plus the direct email fallback; live form registration and inbox notifications are pending deployment setup. Ambient animation pauses while the dialog is open and resumes on close, respecting the existing manual pause setting.

The visible personal name remains removed from the intro and footer. The earlier SEO description is unchanged. Local preview: http://localhost:4185. The preview server was restarted for this revision. Syntax checks, the existing atlas scene/controller verification, and HTTP/markup checks pass. Browser inventory is still empty, so actual visual layout and native-dialog keyboard behavior have not been checked in a live browser. A copy of the preceding index.html, atlas.css, atlas.js and checkpoint is in experiment-backups/before-contact-20261024/.

## Small dock flag - 24 October 2026

Added one muted American flag on a short pole at the pickup dock's outer apron corner. Its thirteen stripes and fifty stars are drawn locally; a small procedural cloth mesh gives it a gentle flutter during Stage 01. Existing Pause/Resume Motion controls now appear at the dock too. Reduced motion keeps the flag static, hidden tabs suspend rendering, and the eagle remains unchanged. The optional flag module is `dist/dock-flag.js`; the pre-flag snapshot is `experiment-backups/before-dock-flag-20261024/`.

Syntax, existing atlas scene/controller checks and HTTP module checks pass. No browser surface is available, so appearance still needs visual review.

## Brand and eagle experiment - 24 October 2026

Review at http://localhost:4185. The homepage keeps the existing live miniature and scrolling journey, with the opening yard and exactly three operational chapters: At the dock, In transit and At the receiver. The supplied headlines, operational copy and help text are installed. The old separate fourth delivery chapter is merged into the receiver chapter; incoming `#delivered` links still reach closeout. The removed top route progress bar has not been restored.

The Atlas now uses a dry van with six actual sample pallet models and a subtle loading/unloading cutaway. A shared, light-reactive AFTER HOURS / dual-slash decal is on both trailer sides and the pickup dock header. The separate seven-stage Load lifecycle page still uses its original reefer and animations.

Stage 02 activates a 144-triangle procedural eagle. It enters from the current camera's top-right boundary, swoops through a real directional-light shadow pass across the trailer roof, then circles with gentle banking and wing movement. Leaving and returning replays the entry. Follow Load / Whole Route use time-based camera damping. The requestAnimationFrame controller targets at most 60 renders per second, animates during dock-flag flutter, transit or camera settling, and suspends on hidden tabs. A Pause/Resume Motion button and static reduced-motion poses are included. Actual hardware frame rate is not guaranteed or measured.

The HUD, narrative and floating callout share the journey state. Counts update while pallets load/unload. Dock and receiver callouts use in-progress wording until the requested six-pallet and clean-POD terminal states are reached; the illustration never labels an unfinished POD as sent. Transit shows the requested BOL CONFIRMED / 68%, and delivery ends at 0 / 6 PALLETS / CLEAN POD SENT / 100%. The header percentage remains scroll progress. Fonts, including JetBrains Mono with its OFL notice, and all 3D assets are local. No blocking loading screen, remote model or runtime font request was added.

Rollback snapshot: `experiment-backups/before-eagle-20261024/` contains the entire previous `dist/`, package configuration and project notes. Restoring those copies returns the prior homepage; extra new, unreferenced modules/fonts can remain or be removed later. This is a local experiment, with no deployment or email sending.

Run `npm.cmd run check`, `npm.cmd run verify`, `npm.cmd run verify:stages` and `npm.cmd run verify:atlas`. The new verifier exercises 18,001 flight poses, 1,001 HUD/cargo states, 2,632 production scene frames at seven sizes, actual geometric shadow/roof intersections, flight re-entry, dry-van decals, dock shutters, camera toggles, pause, reduced motion, resource cleanup, and the production controller's 60fps scheduling cap/hidden-tab behavior. HTTP resources are checked separately. These use a renderer/DOM stub, not a real GPU. Browser inventory is empty and opening the in-app browser reports unavailable, so the eagle's appearance, text layout and actual GPU frame rate still need visual review. Earlier preview PNGs predate this experiment.

## Load lifecycle route - 24 October 2026

Open http://localhost:4185 and choose **Load lifecycle** to visit `/load-lifecycle/` in the same portfolio. Latest direction: keep this page clean and simple. It contains a small heading and seven stage titles, with one short action sentence each (57 action words in total). The long introduction, 24-item checklist, confirmation notes, sample messages and closing essay have been removed.

Keep the sticky vertical seven-stage sidebar, scroll-driven completion checkmarks and reduced-motion behavior. The Three.js/WebGL view has been enlarged and moved out of the sidebar: desktop widths above 1100px use progress, task text and a separate sticky scene column. At 1100px and below the scene sits inline below the heading, including on phones. The mobile progress list remains a numbered rail. Scrolling back resets completion. The concise layout uses a reading position that gradually moves lower while approaching the page end, so all seven stages can become active even on the shorter page. The stage links retain ordinary anchor targets, with enhanced scroll positioning so selecting a stage reliably starts its matching animation; selecting the current stage replays it. There are no forms, messages sent or shipment records updated; the footer identifies the workflow as illustrative.

Files: `dist/load-lifecycle/index.html`, `lifecycle.css`, `progress.js`, `progress-state.js`, `stage-motion.js` and `progress-scene.js`. Local fonts and the original Three.js truck models are reused. The homepage and original truck/trailer model files are unchanged. The enlarged stage view now plays a distinct finite 6-8.6 second sequence for each stage, with Play/Pause and Replay controls. It stops after the sequence, suspends when offscreen or the tab is hidden, and defaults to a final static pose for reduced motion. Explicit playback remains available.

Verification: project syntax and HTTP/fragment checks passed; seven titles and seven short actions remain; no checklist/notes/example-message markup remains; all seven stages activate and complete in four simulated viewport layouts, with reverse reset. The enlarged scene passes all-stage camera-fit checks at seven desktop, tablet, phone and short-window sizes (49 combinations). HTML structure, anchors and served resources also pass. Browser visual review is pending. See `design-qa.md` for prior revisions.

### Stage animations

- Load booked: dispatch sheet checks, envelope sent to the driver, acknowledgement.
- Truck dispatched: truck departure, rolling wheels/road and customer update.
- Checked-in shipper: backing into the pickup dock, arrival marker and check-in confirmation.
- Pickup & BOL reviewed: forklift/pallet loading, scanning the BOL, three review checks and a stamp.
- In transit: moving road/wheels, route checkpoints and customer update.
- At receiver: backing into the receiver, arrival marker and opening trailer doors.
- Delivered: forklift unloading, POD signature and delivery-confirmation stamp.

The paperwork, messages and freight remain illustrative geometry, with no sending or record changes. The visible page keeps its seven short actions. Document headings use local canvas textures; all models and runtime modules are local.

Run `npm.cmd run verify:stages` for seven distinct outcomes, 567 sampled animation poses, 1,029 camera projections, hitch/cargo/door checks, replay determinism and 28 stage-navigation targets. Actual playback code also passed a renderer-stub simulation for autoplay, pause, replay, finite stop, offscreen/tab suspension, reduced motion and disposal. These checks do not replace visual WebGL review; the browser inventory remains empty.

Progress saved for the next session on 2026-10-24. Start with [CHECKPOINT.json](CHECKPOINT.json) for the latest decisions, file map, constraints, verification results, and restart instructions. A timestamped project backup is stored in `D:/Ashish/output/logistics-checkpoints`.

A separate, local version based on the user's selected Route Atlas visual. The earlier portfolios and 3D experiments remain unchanged at ports 4182, 4183, and 4184.

Run `npm.cmd run dev` and open http://localhost:4185. No install or build is needed. Keep the preview running for the user's review.

The landscape is live Three.js geometry, not a hero image. Native page scrolling moves the original orange tractor and white reefer along a shared curved road, into pickup and delivery docks, and through loading and unloading. An orange road trace follows progress. The camera starts with an atlas overview and moves closer to the load. The Whole Route / Follow Load controls change the camera without resetting the load. The top route progress bar was removed at the user's request; the brand and compact progress readout remain in a shorter header.

Desktop text stays with its operational stage. Mobile uses a pinned 3D scene above naturally scrolling chapters. Scrolling backward rewinds the entire deterministic sequence. Reduced-motion preferences use discrete stage poses and instant navigation. Rendering is event-driven; there is no continuous animation loop.

The selected image is composition and art-direction reference only, saved under `references/selected-atlas.png`. It is not shipped as website artwork. Existing original procedural 3D truck and reefer assets are reused from our earlier experiment; the road, river, bridge, landscape and camera behavior are new. All JavaScript, Three.js, and IBM Plex fonts are local with their included MIT/OFL licenses.

This is an illustrative fictional load with six sample pallets. Status notes and paperwork labels demonstrate the workflow; they do not send messages, generate documents, or claim a real customer's activity. Personal claims use the supplied four years of US logistics experience and tracking/communication duties. No email sending, contact integrations, ownership disclosures, or deployment is included.

Files:

- `dist/index.html`, `atlas.css`, `atlas.js`: responsive page, chapters, native-scroll mapping and view controls.
- `dist/journey.js`, `route.js`: deterministic load timeline and shared road curve.
- `dist/landscape.js`, `world.js`: road, river, bridge, forest, yard, warehouses, cargo and forklift.
- `dist/scene.js`, `rig-models.js`: WebGL renderer, two camera modes and model assembly.
- `scripts/verify-journey.mjs`: 2,001 sampled positions, cargo/document states, continuity, exact hitch positions and cab/trailer clearance.

Use `npm.cmd run check` and `npm.cmd run verify`. Browser evidence and remaining visual differences are recorded in `design-qa.md`.

Readability revision: body copy is 16–17px, operational notes are 15–17px, and most supporting labels are 11–13px. Camera buttons have 44px hit areas. Larger notes sit above the truck on mobile. Narrow tablet chapters use natural scrolling to keep the larger copy accessible. Updated previews: `preview-readable-desktop.png` and `preview-readable-mobile.png`.
